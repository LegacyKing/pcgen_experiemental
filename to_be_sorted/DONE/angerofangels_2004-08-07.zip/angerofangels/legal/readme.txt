for whoever gets to overlook this for OGL compliance, etc:

This is a jpg of the copyright notice from the OGL license page
Also a jpg of the block with Designation of Product Identity and Open Game Content

.gif would probably be a better format, but I'm using the Gimp, and haven't d/led the gif-file thing
these are screenshots, so the text is a little fuzzy, esp. the PI/OGC one

somebody email me if you know a good .pdf manipulator for linux ;) (brainface_mike@yahoo.com)
something that can export into .gif/.pdf/whatever
the GIMP has to render it all into an image 
format - slower, lemme know if it's taboo to destribute this, even if it's the most uninteresting
portions of the book